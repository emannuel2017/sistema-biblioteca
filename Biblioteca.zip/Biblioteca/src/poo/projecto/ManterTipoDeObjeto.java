package poo.projecto;

public interface ManterTipoDeObjeto {
	public boolean retornarIndiceDeUmObjeto(String nome);
    public void listarObjetosDeUmaLista();
    public boolean removerUmObjetoDeUmaLista();
    public void atualizarUmObjetoDeUmaLista();
}
