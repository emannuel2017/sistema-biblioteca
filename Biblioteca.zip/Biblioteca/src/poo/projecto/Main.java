package poo.projecto;

public class Main {

	public static void main(String[] args) {
		
		// Sistema.buscarUsuario();
		 Tela.exibirMsg("\t\t\tBem vindo ao sistema de cadastro de Livros");
		 Tela.exibirMsg("Vamos come�ar!\n");
		 
		 Sistema.cadastrarUsuario();
		 System.out.println("Login:"); 
		 Sistema.retornarUmUsuarioCadastradoNoSistema();
		
		
	}
}